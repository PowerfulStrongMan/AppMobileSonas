import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  async getDashboardData() {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      policies: [
        {
          id: 'POL001',
          type: 'Auto',
          status: 'active',
          expiryDate: '2024-12-31',
          premium: 250000
        },
        {
          id: 'POL002',
          type: 'Habitation',
          status: 'active',
          expiryDate: '2024-06-30',
          premium: 180000
        }
      ],
      payments: {
        nextPayment: {
          amount: 45000,
          dueDate: '2024-02-15'
        },
        recentPayments: [
          {
            id: 'PAY001',
            date: '2024-01-15',
            amount: 45000,
            status: 'completed'
          }
        ]
      },
      claims: [
        {
          id: 'CLM001',
          type: 'Auto',
          date: '2024-01-10',
          status: 'en cours',
          amount: 150000
        }
      ],
      notifications: [
        {
          id: 'NOT001',
          title: 'Paiement à venir',
          message: 'Votre prochain paiement est prévu pour le 15 février 2024',
          date: '2024-01-28',
          type: 'payment'
        },
        {
          id: 'NOT002',
          title: 'Mise à jour de réclamation',
          message: 'Votre réclamation CLM001 est en cours de traitement',
          date: '2024-01-27',
          type: 'claim'
        }
      ]
    };
  }
}