import { Component, OnInit } from '@angular/core';
import { DashboardService } from './services/dashboard.service';
import { AuthService } from '../auth/services/auth.service';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss']
})
export class DashboardPage implements OnInit {
  userName: string = '';
  isLoading = true;
  dashboardData: any = {};

  constructor(
    private dashboardService: DashboardService,
    private authService: AuthService,
    private loadingCtrl: LoadingController
  ) {}

  async ngOnInit() {
    const loading = await this.loadingCtrl.create({
      message: 'Chargement du tableau de bord...'
    });
    await loading.present();

    try {
      this.authService.currentUser$.subscribe(user => {
        if (user) {
          this.userName = user.displayName || 'Utilisateur';
        }
      });

      this.dashboardData = await this.dashboardService.getDashboardData();
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      this.isLoading = false;
      await loading.dismiss();
    }
  }

  async doRefresh(event: any) {
    try {
      this.dashboardData = await this.dashboardService.getDashboardData();
    } finally {
      event.target.complete();
    }
  }
}