import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quick-actions',
  templateUrl: './quick-actions.component.html',
  styleUrls: ['./quick-actions.component.scss']
})
export class QuickActionsComponent {
  actions = [
    {
      icon: 'document-text',
      label: 'Nouvelle police',
      route: '/policies/new'
    },
    {
      icon: 'warning',
      label: 'Déclarer sinistre',
      route: '/claims/new'
    },
    {
      icon: 'card',
      label: 'Payer prime',
      route: '/payments/new'
    },
    {
      icon: 'help-circle',
      label: 'Assistance',
      route: '/support'
    }
  ];

  constructor(private router: Router) {}

  navigateTo(route: string) {
    this.router.navigate([route]);
  }
}