import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-claims-summary',
  templateUrl: './claims-summary.component.html',
  styleUrls: ['./claims-summary.component.scss']
})
export class ClaimsSummaryComponent {
  @Input() claims: any[] = [];

  getClaimStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'approuvé':
        return 'success';
      case 'en cours':
        return 'warning';
      case 'refusé':
        return 'danger';
      default:
        return 'medium';
    }
  }

  formatAmount(amount: number): string {
    return new Intl.NumberFormat('fr-CD', {
      style: 'currency',
      currency: 'CDF'
    }).format(amount);
  }
}