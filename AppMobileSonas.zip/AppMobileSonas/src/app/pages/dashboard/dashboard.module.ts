import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardPage } from './dashboard.page';
import { PolicySummaryComponent } from './components/policy-summary/policy-summary.component';
import { PaymentSummaryComponent } from './components/payment-summary/payment-summary.component';
import { ClaimsSummaryComponent } from './components/claims-summary/claims-summary.component';
import { NotificationsComponent } from './components/notifications/notifications.component';
import { QuickActionsComponent } from './components/quick-actions/quick-actions.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    DashboardRoutingModule,
    TranslateModule.forChild()
  ],
  declarations: [
    DashboardPage,
    PolicySummaryComponent,
    PaymentSummaryComponent,
    ClaimsSummaryComponent,
    NotificationsComponent,
    QuickActionsComponent
  ]
})
export class DashboardModule {}