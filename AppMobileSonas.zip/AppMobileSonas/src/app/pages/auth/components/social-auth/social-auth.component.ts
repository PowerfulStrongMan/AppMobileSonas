import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-social-auth',
  templateUrl: './social-auth.component.html',
  styleUrls: ['./social-auth.component.scss']
})
export class SocialAuthComponent {
  constructor(private authService: AuthService) {}

  async loginWithGoogle(): Promise<void> {
    try {
      // Implement Google login
      console.log('Google login clicked');
    } catch (error) {
      console.error('Google login error:', error);
    }
  }

  async loginWithFacebook(): Promise<void> {
    try {
      // Implement Facebook login
      console.log('Facebook login clicked');
    } catch (error) {
      console.error('Facebook login error:', error);
    }
  }
}