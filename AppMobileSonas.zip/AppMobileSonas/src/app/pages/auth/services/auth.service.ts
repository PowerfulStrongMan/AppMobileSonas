import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';

export interface User {
  uid: string;
  email: string;
  displayName?: string;
  phoneNumber?: string;
  photoURL?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private router: Router,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController
  ) {
    // Simulate loading user from storage
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }

  async login(email: string, password: string): Promise<void> {
    const loading = await this.loadingCtrl.create({
      message: 'Connexion en cours...'
    });
    await loading.present();

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const user: User = {
        uid: 'test-uid',
        email: email,
        displayName: 'Test User'
      };

      localStorage.setItem('currentUser', JSON.stringify(user));
      this.currentUserSubject.next(user);
      
      await this.router.navigate(['/dashboard']);
      this.showToast('Connexion réussie', 'success');
    } catch (error) {
      this.showToast('Erreur de connexion', 'danger');
      throw error;
    } finally {
      await loading.dismiss();
    }
  }

  async register(email: string, password: string, displayName: string): Promise<void> {
    const loading = await this.loadingCtrl.create({
      message: 'Création du compte...'
    });
    await loading.present();

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const user: User = {
        uid: 'new-user-uid',
        email: email,
        displayName: displayName
      };

      localStorage.setItem('currentUser', JSON.stringify(user));
      this.currentUserSubject.next(user);
      
      await this.router.navigate(['/dashboard']);
      this.showToast('Compte créé avec succès', 'success');
    } catch (error) {
      this.showToast('Erreur lors de la création du compte', 'danger');
      throw error;
    } finally {
      await loading.dismiss();
    }
  }

  async resetPassword(email: string): Promise<void> {
    const loading = await this.loadingCtrl.create({
      message: 'Envoi du lien de réinitialisation...'
    });
    await loading.present();

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      this.showToast('Instructions envoyées par email', 'success');
      await this.router.navigate(['/auth/login']);
    } catch (error) {
      this.showToast('Erreur lors de l\'envoi', 'danger');
      throw error;
    } finally {
      await loading.dismiss();
    }
  }

  async logout(): Promise<void> {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    await this.router.navigate(['/auth/login']);
    this.showToast('Déconnexion réussie', 'success');
  }

  private async showToast(message: string, color: string): Promise<void> {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000,
      color,
      position: 'bottom'
    });
    await toast.present();
  }
}