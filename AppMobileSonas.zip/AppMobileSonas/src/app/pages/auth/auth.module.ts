import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { AuthRoutingModule } from './auth-routing.module';
import { LoginPage } from './login/login.page';
import { RegisterPage } from './register/register.page';
import { ForgotPasswordPage } from './forgot-password/forgot-password.page';
import { AuthService } from './services/auth.service';
import { SocialAuthComponent } from './components/social-auth/social-auth.component';
import { AuthFormComponent } from './components/auth-form/auth-form.component';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    ReactiveFormsModule,
    AuthRoutingModule,
    TranslateModule.forChild()
  ],
  declarations: [
    LoginPage,
    RegisterPage,
    ForgotPasswordPage,
    SocialAuthComponent,
    AuthFormComponent
  ],
  providers: [AuthService]
})
export class AuthModule {}